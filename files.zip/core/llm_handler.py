from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.chains import create_retrieval_chain
from typing import List, Dict, Any

from config import LLM_MODEL

def create_qa_chain(retriever):
    """
    Creates a Retrieval-Augmented Generation (RAG) chain that combines
    document retrieval with LLM-based question answering.
    """
    llm = ChatOpenAI(model_name=LLM_MODEL, temperature=0.1)

    # This prompt template is crucial for guiding the LLM.
    # It instructs the LLM to base its answer strictly on the provided context,
    # cite the sources, and structure the output as required.
    prompt_template = """
    You are an intelligent assistant for a Query-Retrieval System. Your task is to answer questions based *only* on the provided document context.
    If the information is not in the context, state that clearly. Do not use any external knowledge.

    CONTEXT:
    {context}

    QUESTION:
    {input}

    INSTRUCTIONS:
    1.  Read the context carefully.
    2.  Formulate a direct and concise answer to the question.
    3.  Your answer must be based *solely* on the text provided in the context.
    4.  If the context does not contain the answer, reply with: "The document does not provide information on this topic."
    5.  Provide a brief "Decision Rationale" explaining how you arrived at your answer by referencing the key phrases from the context.

    ANSWER:
    """

    prompt = PromptTemplate(
        template=prompt_template,
        input_variables=["context", "input"]
    )

    # This chain will pass the retrieved documents and the question to the LLM.
    question_answer_chain = create_stuff_documents_chain(llm, prompt)
    
    # This retrieval chain orchestrates the whole process.
    rag_chain = create_retrieval_chain(retriever, question_answer_chain)

    return rag_chain

async def get_answers(questions: List[str], rag_chain) -> List[Dict[str, Any]]:
    """
    Processes a list of questions using the RAG chain and returns the answers.
    """
    answers = []
    for question in questions:
        print(f"Processing question: '{question}'")
        response = await rag_chain.ainvoke({"input": question})
        
        # The 'answer' key holds the final generated response from the LLM.
        # We also include the retrieved documents for explainability.
        answers.append({
            "question": question,
            "answer": response["answer"],
            "retrieved_context": [doc.page_content for doc in response["context"]]
        })
    return answers