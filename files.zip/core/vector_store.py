from langchain_openai import OpenAIEmbeddings
from langchain_pinecone import PineconeVectorStore
from pinecone import Pinecone, ServerlessSpec
from typing import List
from langchain.docstore.document import Document

from config import (
    PINECONE_API_KEY,
    PINECONE_ENVIRONMENT,
    PINECONE_INDEX_NAME,
    EMBEDDING_MODEL,
    TOP_K_RESULTS
)

pc = Pinecone(api_key=PINECONE_API_KEY, environment=PINECONE_ENVIRONMENT)

def get_or_create_vector_store(chunks: List[Document], force_recreate: bool = False) -> PineconeVectorStore:
    """
    Initializes the Pinecone vector store. If the index doesn't exist, it creates one.
    It then populates the index with the document chunks.
    """
    embeddings = OpenAIEmbeddings(model=EMBEDDING_MODEL)

    if force_recreate and PINECONE_INDEX_NAME in pc.list_indexes().names():
        print(f"Deleting existing index '{PINECONE_INDEX_NAME}'...")
        pc.delete_index(PINECONE_INDEX_NAME)

    if PINECONE_INDEX_NAME not in pc.list_indexes().names():
        print(f"Creating new index '{PINECONE_INDEX_NAME}'...")
        pc.create_index(
            name=PINECONE_INDEX_NAME,
            dimension=1536,  # Dimension for text-embedding-3-small
            metric='cosine',
            spec=ServerlessSpec(
                cloud='aws',
                region='us-east-1'
            )
        )
        print("Index created. Populating with new document chunks...")
        vector_store = PineconeVectorStore.from_documents(chunks, embeddings, index_name=PINECONE_INDEX_NAME)
    else:
        print("Index already exists. Populating with new document chunks...")
        vector_store = PineconeVectorStore.from_documents(chunks, embeddings, index_name=PINECONE_INDEX_NAME)
    
    print("Vector store is ready.")
    return vector_store

def get_retriever(chunks: List[Document]):
    """
    Creates a retriever from the vector store to find relevant document chunks.
    """
    vector_store = get_or_create_vector_store(chunks)
    return vector_store.as_retriever(search_kwargs={"k": TOP_K_RESULTS})