import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# API Keys and Environment
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
PINECONE_ENVIRONMENT = os.getenv("PINECONE_ENVIRONMENT")
PINECONE_INDEX_NAME = "hackrx-retrieval-system"

# Authentication Token for the API
API_BEARER_TOKEN = "14136f363323c2af817656c9a0fb6542f8b7c643682417a1e4e55c9ad87b81f2"

# LLM and Embedding Configuration
LLM_MODEL = "gpt-4o"
EMBEDDING_MODEL = "text-embedding-3-small"

# Document Processing Configuration
CHUNK_SIZE = 1500
CHUNK_OVERLAP = 200

# Vector Store Configuration
TOP_K_RESULTS = 5 # Number of relevant chunks to retrieve